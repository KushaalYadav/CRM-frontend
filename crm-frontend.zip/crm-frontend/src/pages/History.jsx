import { useEffect, useState } from 'react';
import axios from 'axios';

const History = () => {
  const [campaigns, setCampaigns] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/campaigns')
      .then(res => setCampaigns(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="container">
      <h2>📜 Campaign History</h2>
      {campaigns.length === 0 && <p>No campaigns yet.</p>}
      {campaigns.map((c, idx) => (
        <div key={idx} style={{ marginBottom: '1rem', padding: '1rem', border: '1px solid #ccc', borderRadius: '6px' }}>
          <p><strong>Message:</strong> {c.message}</p>
          <p><strong>Audience Size:</strong> {c.audienceSize}</p>
          <p><strong>Sent:</strong> {c.sent}</p>
          <p><strong>Failed:</strong> {c.failed}</p>
        </div>
      ))}
    </div>
  );
};

export default History;
