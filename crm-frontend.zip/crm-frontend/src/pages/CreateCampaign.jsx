import { useState } from 'react';
import RuleBuilder from '../components/RuleBuilder';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const CreateCampaign = () => {
  const [rules, setRules] = useState([]);
  const [message, setMessage] = useState('');
  const [audienceSize, setAudienceSize] = useState(null);
  const navigate = useNavigate();

  const previewSize = async () => {
    const res = await axios.post('http://localhost:5000/api/preview-size', { rules });
    setAudienceSize(res.data.count);
  };

  const submitCampaign = async () => {
    await axios.post('http://localhost:5000/api/create-campaign', { rules, message });
    navigate('/history');
  };

  return (
    <div className="container">
      <h2>Create Campaign</h2>
      <RuleBuilder onChange={setRules} />

      <textarea
        placeholder="Enter your campaign message"
        rows={4}
        style={{ width: '100%' }}
        value={message}
        onChange={e => setMessage(e.target.value)}
      />

      <div style={{ marginTop: '10px' }}>
        <button className="secondary-btn" onClick={previewSize}>👀 Preview Audience</button>
        {audienceSize !== null && <span style={{ marginLeft: '1rem' }}>Size: <strong>{audienceSize}</strong></span>}
      </div>

      <button className="primary-btn" onClick={submitCampaign}>🚀 Launch Campaign</button>
    </div>
  );
};

export default CreateCampaign;
