import { useState } from 'react';

const fields = [
  { label: "Total Spent", value: "totalSpent" },
  { label: "Visits", value: "visits" },
  { label: "Inactive Days", value: "inactiveDays" }
];

const operators = [">", "<", "=", ">=", "<="];

const RuleBuilder = ({ onChange }) => {
  const [rules, setRules] = useState([]);

  const addRule = () => {
    setRules([...rules, { field: '', operator: '', value: '', connector: 'AND' }]);
  };

  const updateRule = (index, key, value) => {
    const newRules = [...rules];
    newRules[index][key] = value;
    setRules(newRules);
    onChange(newRules);
  };

  return (
    <div>
      {rules.map((rule, idx) => (
        <div className="rule-row" key={idx}>
          <select onChange={e => updateRule(idx, 'field', e.target.value)} value={rule.field}>
            <option value="">Field</option>
            {fields.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
          </select>

          <select onChange={e => updateRule(idx, 'operator', e.target.value)} value={rule.operator}>
            <option value="">Op</option>
            {operators.map(op => <option key={op} value={op}>{op}</option>)}
          </select>

          <input
            type="text"
            placeholder="Value"
            value={rule.value}
            onChange={e => updateRule(idx, 'value', e.target.value)}
          />

          {idx !== 0 && (
            <select onChange={e => updateRule(idx, 'connector', e.target.value)} value={rule.connector}>
              <option value="AND">AND</option>
              <option value="OR">OR</option>
            </select>
          )}
        </div>
      ))}
      <button onClick={addRule} className="primary-btn">➕ Add Rule</button>
    </div>
  );
};

export default RuleBuilder;
