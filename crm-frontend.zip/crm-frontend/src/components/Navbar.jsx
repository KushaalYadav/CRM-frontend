import { Link } from 'react-router-dom';

const Navbar = () => (
  <nav>
    <h2>📢 Mini CRM</h2>
    <div>
      <Link to="/">Create Campaign</Link>
      <Link to="/history">History</Link>
    </div>
  </nav>
);

export default Navbar;
